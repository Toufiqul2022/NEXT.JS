import AddItemPage from "@/app/items/new/page";

export default function DashboardAddProduct() {
  return (
    <div>
      <AddItemPage />
    </div>
  );
}
